

### Install 




### SYNOPSIS

  sticky [option] [files]

  * DESCRIPTION

Sticky on terminal.

By deault it will read from stdin.



  * Options:

    -v : list all stickies

    -clean: clean up stickies
