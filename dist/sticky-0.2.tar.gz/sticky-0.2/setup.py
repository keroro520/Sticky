# -*- coding: utf-8 -*-

import distutils.core

version = '0.2'

distutils.core.setup(
    name='sticky',
    version=version,
    packages=['sticky'],
    author='Guozhen Wang',
    author_email='keroro520@gmail.com',
    url='http://www.keroro520.com',
    description='My First Python Egg'
    )
